# Terrário (Android)

Fase 1: app Android que roda o protótipo HTML (app/src/main/assets/index.html) numa WebView em tela cheia.

Para atualizar o visual/áudio do app depois de mudar o artefato: substitua app/src/main/assets/index.html pelo novo terrario.html e suba o zip de novo.
Fase 2 (próxima): motor de áudio nativo (C++/Oboe) ligado ao mesmo HTML por uma ponte JavaScript.
